class ExistingClass:
    pass
